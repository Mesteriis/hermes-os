# ADR-0090 Persona-Native Compatibility API Bridge

Status: Proposed

Clarifies:

- ADR-0084 Persona Intelligence System

## Context

ADR-0084 defines Persona as the target domain entity, while current durable
storage and much of the compatibility API still use `persons`, `person_id` and
`/api/v1/persons/*`.

Hermes needs Persona-native read and write surfaces so new UI and agent flows
can speak the target language. A physical schema rename from `persons` to
`personas` is still a separate migration decision because existing routes,
tables, projections and tests depend on compatibility names.

## Decision

Expose a Persona-native compatibility API bridge under `/api/v1/personas/*`.

The bridge may read and write the current compatibility projection, but its
public contract uses Persona terminology and target-model shapes.

Allowed in this bridge:

- read Persona list/detail models from compatibility storage;
- update owner-editable Persona identity fields such as display name;
- set the single Owner Persona through Persona-native request fields;
- return the same Persona read model after writes;
- keep legacy identifiers in an explicit `compatibility` section.

Not allowed in this bridge:

- rename PostgreSQL tables, columns or migrations from `persons` to `personas`;
- remove `/api/v1/persons/*` compatibility routes;
- change Persona identity or `persona_type` without explicit validation rules;
- create separate Self/UserProfile storage;
- auto-merge identity traces without review.

The initial write bridge is intentionally narrow. It updates:

```yaml
PersonaUpdate:
  identity:
    display_name:
  is_self:
```

`is_self: true` sets the requested Persona as the only Owner Persona. `is_self:
false` is not a supported way to remove the Owner Persona; ownership must move
to another Persona instead.

## Consequences

Positive:

- New code can use Persona terminology without waiting for physical schema
  migration.
- Compatibility state remains stable for existing workflows.
- Owner Persona semantics are available through the target API language.
- The future schema migration has a clearer API contract to preserve.

Negative:

- The backend still contains compatibility names internally.
- The bridge must be maintained until the physical schema/API migration ADR is
  accepted and implemented.
- Some target-model fields remain read-only until their source-of-truth
  boundaries are defined.

## Follow-Up

- Design a physical schema migration ADR before renaming tables or columns.
- Expand write support only for fields with clear source-of-truth ownership and
  review semantics.
- Keep compatibility gaps visible in `docs/refactoring/implementation-alignment-plan.md`.
